# Manipulators Detection > 2023-03-04 2:22pm
https://universe.roboflow.com/object-detection/manipulators-detection

Provided by a Roboflow user
License: Public Domain

